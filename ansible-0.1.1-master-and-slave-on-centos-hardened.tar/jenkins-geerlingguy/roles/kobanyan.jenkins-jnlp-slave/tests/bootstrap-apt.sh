#!/bin/sh
sudo apt-get update -y
sudo apt-get upgrade -y
sudo apt-get install python openjdk-8-jre-headless -y
