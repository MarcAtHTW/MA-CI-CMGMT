#!/bin/sh
sudo yum update -y
sudo yum install java-1.8.0-openjdk-headless wget -y
